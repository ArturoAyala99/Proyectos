<html>

<head>

 <title>AGREGAR</title>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"> <!--para que sea responsivo-->
  <link rel = "stylesheet" type = "text/css" href = "bootstrap-4.5.3-dist/css/bootstrap.min.css">
  <link rel = "stylesheet" type = "text/css" href = "bootstrap-4.5.3-dist/css/bootstrap-grid.min.css">
  <link rel = "stylesheet" type = "text/css" href = "bootstrap-4.5.3-dist/css/bootstrap-reboot.min.css">

  <script type = "text/JavaScript" src = "bootstrap-4.5.3-dist/js/jquery-3.5.1.min.js"> </script>
  <script type = "text/JavaScript" src = "bootstrap-4.5.3-dist/js/bootstrap.min.js"> </script>
  <script type = "text/JavaScript" src = "bootstrap-4.5.3-dist/js/bootstrap.bundle.min.js"> </script>

</head>

<body>

<?php

  if(isset($_POST['enviar'])){
      $nombre= $_POST['nombre'];
      $nocontrol = $_POST['nocontrol'];

      include("conexion.php");

      $sql = "INSERT INTO alumnos(nombre, nocontrol) VALUES (' ".$nombre. " ', ' ".$nocontrol. " ' )";

      $resultado = mysqli_query($conexion, $sql);

      if($resultado)
      {
          //los datos ingresaron a la bd
          echo "<script language='JavaScript'>  alert ('los datos ingresaron a la bd'); 
          location.assign('index.php');
          </script>";
      }
      else
      {
          //los datos no ingresaron a la bd
          echo "<script language='JavaScript'>  alert ('ERROR: los datos NO ingresaron a la bd'); 
          location.assign('index.php');
          </script>";
      }

      mysqli_close($conexion);
  }else{

?>
    
  <div class = "text-center">
  
    <h1>AGREGAR nuevo Alumno</h1>

    <form action="<?=$_SERVER['PHP_SELF']?>" method="post">

        <label> Nombre: </label>
        <input type="text" name="nombre"> <br><br>

        <label> NoControl: </label>
        <input type="text" name="nocontrol"> <br><br>

        <input type="submit" class = "btn btn-dark" name="enviar" value = "AGREGAR">

        <a href="index.php" >Regresar</a>

    </form>

  </div>

  <?php
  
  }

  ?>

<img src = "img/nuevo.jpg" class = "rounded mx-auto d-block img-fluid" width = "400px">

</body>


</html>