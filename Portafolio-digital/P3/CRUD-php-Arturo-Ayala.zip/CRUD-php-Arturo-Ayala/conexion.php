<?php

$dbname = "Escuela";
$dbuser = "root"; //es el superusuario
$dbhost = "localhost";
$dbpass = "";

$conexion = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);

?>