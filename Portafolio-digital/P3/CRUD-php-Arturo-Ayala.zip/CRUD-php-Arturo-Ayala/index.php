<html> 

<head>
  <title>Lista de Alumnos</title>


  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"> <!--para que sea responsivo-->
  <link rel = "stylesheet" type = "text/css" href = "bootstrap-4.5.3-dist/css/bootstrap.min.css">
  <link rel = "stylesheet" type = "text/css" href = "bootstrap-4.5.3-dist/css/bootstrap-grid.min.css">
  <link rel = "stylesheet" type = "text/css" href = "bootstrap-4.5.3-dist/css/bootstrap-reboot.min.css">

  <script type = "text/JavaScript" src = "bootstrap-4.5.3-dist/js/jquery-3.5.1.min.js"> </script>
  <script type = "text/JavaScript" src = "bootstrap-4.5.3-dist/js/bootstrap.min.js"> </script>
  <script type = "text/JavaScript" src = "bootstrap-4.5.3-dist/js/bootstrap.bundle.min.js"> </script>


  <script type="text/JavaScript">

   
    function confirmar()
    {
      return confirm('¿Seguro desea eliminar?');
    }

  </script>

</head>


<body> <!--cuerpo de la página-->

<?php

include("conexion.php");

//select
$sql = "SELECT * FROM alumnos";
$resultado = mysqli_query($conexion, $sql);

?>

  <div class = "text-center">
    <h1>Lista de alumnos</h1>

    <a href = "agregar.php">Nuevo Alumno</a> <br><br>
  </div>

  <div class = "container">
    <table border = "1" class = "table table-hover table-borderless">

      <thead>
        <tr>
            <th>No.</th>
            <th>Nombre</th>
            <th>No. Control</th>
            <th>Acciones</th>
        </tr>
      </thead>

      <tbody>

        <?php
        
          while($filas = mysqli_fetch_assoc($resultado)) {
         

        ?>

        <tr>
           <td> <?php echo $filas['id'] ?> </td>
           <td> <?php echo $filas['nombre'] ?> </td>
           <td> <?php echo $filas['nocontrol'] ?> </td>
           <td>
<?php echo "<a class = 'btn btn-primary' data-role='button' href = 'editar.php?id=".$filas['id']." ' > EDITAR </a>"; ?>
          -
<?php echo "<a class = 'btn btn-danger' data-role='button' href = ' eliminar.php?id=".$filas['id']." ' onclick='return confirmar()' > ELIMINAR </a>"; ?>
            
          

           </td>
        </tr>
        <?php

          }

        ?>

      </tbody>  

    </table> 

  </div>

    <img src = "img/alumnos.jpg" class = " rounded mx-auto d-block img-fluid rounded-circle" style = "width:400px; height: 400px"> <!--para que se adapte-->

  <?php
    mysqli_close($conexion);
  ?>
</body>

</html>