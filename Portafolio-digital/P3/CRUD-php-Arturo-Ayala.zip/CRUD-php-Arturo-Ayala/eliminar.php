<?php

$id = $_GET['id'];

include('conexion.php');

$sql = "DELETE FROM alumnos WHERE id = ' ".$id." ' ";

$resultado = mysqli_query($conexion, $sql);

if($resultado)
      {
          //cuando se logró eliminar
        echo "<script language='JavaScript'>  alert ('los datos se eliminaron de la bd'); 
        location.assign('index.php');
        </script>";
      }
      else
      {
        echo "<script language='JavaScript'>  alert ('los datos no se eliminaron de la bd'); 
        location.assign('index.php');
        </script>";
      }
      mysqli_close($conexion);

?>