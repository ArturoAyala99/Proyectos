<?php

if( isset($_POST["nombre"]) && isset($_POST["select"]) && isset($_POST["cantidad"]) && isset($_POST["ingredientes"]) ) //el _POST trabaja con el atributo name de html
{
    $precio = 0;

    $nombre = $_POST["nombre"];
    $select = $_POST["select"];
    $cantidad = $_POST["cantidad"];
    $ingredientes = $_POST["ingredientes"];

    /*if($nombre == "" || $select == "" || $cantidad == "" || $ingredientes == "")
    {
        echo 'Completa los campos';
    }*/

    switch ($select)
    {
        case "1":
            $precio = 100;
        break;

        case "2":
            $precio = 120;
        break;

        case "3":
            $precio = 150;
        break;

        case "4":
            $precio = 200;
        break;
    }


    if ($ingredientes > 3)
    {
        $ingredientes = ($ingredientes - 3) * 10;
        $precio = $precio + $ingredientes;
    }

    $precio = $precio * $cantidad;

    print 'El precio es:';

    echo $precio;

}

?>