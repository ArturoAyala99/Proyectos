<?php

copy($_FILES['archivo']['tap_name'],$_FILES['archivo']['name']); //para subir archivos
echo 'se subio el archivo'. $_FILES['archivo']['name'];

if( isset($_GET["nombre"]) && isset($_GET["carrera"]) && isset($_GET["date"]) && isset($_GET["sexo"]) ) //el _POST trabaja con el atributo name de html
{
    $nombre = $_GET["nombre"];
    $carrera = $_GET["carrera"];
    $date = $_GET["date"];
    $sexo = $_GET["sexo"];
}

echo 'Por medio de la presente, el director de la Universidad Empresarial hace CONSTAR: Que el alumno '. $nombre.
' de la carrera '. $carrera. ' se encuentra actualmente cursando de manera satisfactoria el periodo escolar '. $date;
echo 'Sexo '. $sexo;


?>