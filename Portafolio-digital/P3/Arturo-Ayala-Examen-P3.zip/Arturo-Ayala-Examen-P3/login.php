<!DOCTYPE html>
<html>
    <head>

        <title>Página Web con Principal</title>

        <meta charset="utf-8">

        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"> <!--para que sea responsivo-->
        <link rel = "stylesheet" type = "text/css" href = "bootstrap-4.5.3-dist/css/bootstrap.min.css">
        <link rel = "stylesheet" type = "text/css" href = "bootstrap-4.5.3-dist/css/bootstrap-grid.min.css">
        <link rel = "stylesheet" type = "text/css" href = "bootstrap-4.5.3-dist/css/bootstrap-reboot.min.css">

        <script type = "text/JavaScript" src = "bootstrap-4.5.3-dist/js/jquery-3.5.1.min.js"> </script>
        <script type = "text/JavaScript" src = "bootstrap-4.5.3-dist/js/bootstrap.min.js"> </script>
        <script type = "text/JavaScript" src = "bootstrap-4.5.3-dist/js/bootstrap.bundle.min.js"> </script>

    </head>


    <body class = "bg-dark">
<?php
  session_start();

  if(isset($_POST['iniciar']))
   {
        $email2 = $_POST['email2'];
        $contrasena2 = $_POST['contrasena2'];

        include("conexion.php");

        $sql = "SELECT nombre, email, contrasena FROM usuario WHERE email='".$email2."' AND contrasena='".$contrasena2."'   ";

        $resultado = mysqli_query($conexion, $sql);
        $datos= mysqli_fetch_assoc($resultado);

        if(!empty($_POST['remember'])){
            setcookie ("email2",$_POST['email2'],time()+ (10 * 365 * 24 * 60 * 60));
            setcookie ("contrasena2",$_POST['contrasena2'],time()+ (10 * 365 * 24 * 60 * 60));
        }
        else
        {
            if(isset($_COOKIE["email2"]))
            {
             setcookie ("email2","");
            }
            if(isset($_COOKIE["contrasena2"]))
            {
             setcookie ("contrasena2","");
            }
        }

        if($contrasena==$datos['contrasena2']){
            
            echo "<script language='JavaScript'>
              alert('Bienvenido  ');
              location.assign('principal.php?nombre=".$datos['nombre']."');
            </script>";
          }else{
            echo "<script language='JavaScript'>
              alert('datoss incorrectos  ');
              location.assign('login.php');
            </script>";

        }


        mysqli_close($conexion);
    }else{




  if(isset($_POST['enviar'])){
      $nombre= $_POST['nombre'];
      $apellido = $_POST['apellido'];
      $email = $_POST['email'];
      $contrasena = $_POST['contrasena'];

      include("conexion.php");

      $sql = "INSERT INTO usuario(nombre, apellido, email, contrasena) VALUES (' ".$nombre. " ', ' ".$apellido. " ', ' ".$email. " ', ' ".$contrasena. " ' )";

      $resultado = mysqli_query($conexion, $sql);

      if($resultado)
      {
          //los datos ingresaron a la bd
          echo "<script language='JavaScript'>  alert ('los datos ingresaron a la bd'); 
          location.assign('principal.php');
          </script>";
      }
      else
      {
          //los datos no ingresaron a la bd
          echo "<script language='JavaScript'>  alert ('ERROR: los datos NO ingresaron a la bd'); 
          location.assign('principal.php');
          </script>";
      }

      mysqli_close($conexion);
  }else{

?>

        <header> 

            <div class="container color bg-light" style="opacity:.8;"> <!--cabezote blanco-->

                <div class = "row">

                    <div class="col-sm">

                      <h5>Usuario</h5>
                    </div>

                    <div class="col-sm">

                      <a href = "principal.php" class="nav-link text-dark"> <h1 class="text-center">Tienda online</h1> </a>
                    </div>

                    <div class="col-sm">
    
                      <a href> <img src="img/login.jpg" class = "rounded mx-auto d-block img-fluid float-right" width = "50px"> </a>
                    </div>
                </div>
            </div>
        </header> <br><br>


        <div class="container">
            <div class="row">
                <div class="col-sm-6 bg-success text-center"><!--INICIAR SESION-->

                    <h2>Inicio de Sesión</h2>
                    <form action="<?=$_SERVER['PHP_SELF']?>" method="post">

                        <div class="row">

                            <div class="form-group col-6"> <!--col-md es para ocupar mitad y mitad de contenido-->

                                <label>Correo</label>
                                <input type="email" id="email2" name="email2" class="form-control" value= "<?php if(isset($_COOKIE["email2"])) { echo $_COOKIE["email2"]; } ?>" >
                            </div>

                            <div class="form-group col-6"> <!--col-md es para ocupar mitad y mitad de contenido-->

                                <label>Contraseña</label>
                                <input type="password" id="contrasena2" name="contrasena2" class="form-control" value= "<?php if(isset($_COOKIE["contrasena2"])) { echo $_COOKIE["contrasena2"]; } ?>" >
                            </div>

                            <div class="form-group col-md"> <!--esta clase es para que el boton salga alineado-->

                                <button type="submit" name="iniciar" value="iniciar" class="btn btn-outline-warning">Iniciar Sesion</button>
                                <input type="checkbox" name="remember" value="" <?php if(isset($_COOKIE["email"])) { ?> checked <?php } ?>>
                            </div>
                        </div>
                    </form>
                </div>


                <div class="col-sm-6 bg-primary text-center"> <!--CUENTA NUEVA-->

                    <h2>Crear Cuenta</h2>
                    <form action="<?=$_SERVER['PHP_SELF']?>" method="post">
                        <div class="row">

                            <div class="form-group col-6">

                                <label>Nombre</label>
                                <input type="text" id="nombre" name="nombre" class="form-control" required>
                            </div>

                            <div class="form-group col-6">

                                <label>Apellido</label>
                                <input type="text" id="apellido" name="apellido" class="form-control" required>
                            </div>

                            <div class="form-group col-6"> <!--col-md es para ocupar mitad y mitad de contenido-->

                                <label>Correo</label>
                                <input type="email" id="email" name="email" class="form-control" required>
                            </div>

                            <div class="form-group col-6"> <!--col-md es para ocupar mitad y mitad de contenido-->

                                <label>Contraseña</label>
                                <input type="password" id="contrasena" name="contrasena" class="form-control" required>
                            </div>

                            <div class="form-group col-md"> <!--esta clase es para que el boton salga alineado-->

                                <button type="submit" class="btn btn-outline-warning" name="enviar" value="AGREGAR">Crear Cuenta</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
<?php
  
}

?>
<?php
  
}

?>

    </body>
</html>