<!DOCTYPE html>
<html>
    <head>

        <title>Página Web con Principal</title>

        <meta charset="utf-8">

        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"> <!--para que sea responsivo-->
        <link rel = "stylesheet" type = "text/css" href = "bootstrap-4.5.3-dist/css/bootstrap.min.css">
        <link rel = "stylesheet" type = "text/css" href = "bootstrap-4.5.3-dist/css/bootstrap-grid.min.css">
        <link rel = "stylesheet" type = "text/css" href = "bootstrap-4.5.3-dist/css/bootstrap-reboot.min.css">

        <script type = "text/JavaScript" src = "bootstrap-4.5.3-dist/js/jquery-3.5.1.min.js"> </script>
        <script type = "text/JavaScript" src = "bootstrap-4.5.3-dist/js/bootstrap.min.js"> </script>
        <script type = "text/JavaScript" src = "bootstrap-4.5.3-dist/js/bootstrap.bundle.min.js"> </script>

    </head>


    <body class = "bg-dark">
        <header> 

            <div class="container color bg-light" style="opacity:.8;"> <!--cabezote blanco-->

                <div class = "row">

                    <div class="col-sm">

                      <h5>Usuario</h5>
                    </div>

                    <div class="col-sm">

                      <a href = "principal.php" class="nav-link text-dark"> <h1 class="text-center">Tienda online</h1> </a>
                    </div>

                    <div class="col-sm">
    
                      <a href> <img src="img/login.jpg" class = "rounded mx-auto d-block img-fluid float-right" width = "50px"> </a>
                    </div>
                </div>
            </div>
        </header> <br><br>


        <div class="container">

            <div class="row">

                <div class="col-sm-4">

                    <div class="panel panle-primary">

                        <div class="panel-heading text-light"> Reloj De Bethune DB 28 </div>
                        <div clas="panle body"> <img src="img/1.jpg" class="image-responsive" style="width:100%" alt="Image"> </div>
                        <div class="panel-footer text-light">Precio :  250.000 EUROS </div>
                        <div class="panel-footer text-light float-right"> <a href ="#"> Agregar al carrito </a> </div>
                    </div>
                </div>
                <div class="col-sm-4">

                    <div class="panel panle-primary">

                        <div class="panel-heading text-light"> Reloj HYT H1 </div>
                        <div clas="panle body"> <img src="img/2.jpg" class="image-responsive" style="width:100%; height:350px" alt="Image"> </div>
                        <div class="panel-footer text-light">Precio : 45.000 USD </div>
                        <div class="panel-footer text-light float-right"> <a href ="#"> Agregar al carrito </a> </div>
                    </div>
                </div>
                <div class="col-sm-4">

                    <div class="panel panle-primary">

                        <div class="panel-heading text-light"> Reloj Lange & Söhne </div>
                        <div clas="panle body"> <img src="img/3.jpg" class="image-responsive" style="width:100%" alt="Image"> </div>
                        <div class="panel-footer text-light">Precio :  300.000 EUROS </div>
                        <div class="panel-footer text-light float-right"> <a href ="#"> Agregar al carrito </a> </div>
                    </div>
                </div>
            </div>
        </div><br>


        <div class="container">

            <div class="row">

                <div class="col-sm-4">

                    <div class="panel panle-primary">

                        <div class="panel-heading text-light"> Reloj Franck Muller Aeternitas Mega 4 </div>
                        <div clas="panle body"> <img src="img/4.jpg" class="image-responsive" style="width:100%" alt="Image"> </div>
                        <div class="panel-footer text-light">Precio :  90.000 EUROS </div>
                        <div class="panel-footer text-light float-right"> <a href ="#"> Agregar al carrito </a> </div>
                        
                    </div>
                </div>
                <div class="col-sm-4">

                    <div class="panel panle-primary">

                        <div class="panel-heading text-light"> Reloj Patek Philippe 1928 </div>
                        <div clas="panle body"> <img src="img/5.jpg" class="image-responsive" style="width:100%" alt="Image"> </div>
                        <div class="panel-footer text-light">Precio : 45.000 USD </div>
                        <div class="panel-footer text-light float-right"> <a href ="#"> Agregar al carrito </a> </div>
                    </div>
                </div>
                <div class="col-sm-4">

                    <div class="panel panle-primary">

                        <div class="panel-heading text-light"> Reloj Patek Philippe 5004T </div>
                        <div clas="panle body"> <img src="img/6.jpg" class="image-responsive" style="width:100%" alt="Image"> </div>
                        <div class="panel-footer text-light">Precio :  300.000 EUROS </div>
                        <div class="panel-footer text-light float-right"> <a href ="#"> Agregar al carrito </a> </div>
                    </div>
                </div>
            </div>
        </div><br>


        <div class="container" style="margin-bottom:20px">

            <div class="row">

                <div class="col-sm-4">

                    <div class="panel panle-primary">

                        <div class="panel-heading text-light"> Reloj Breguet Antique Number 2667 </div>
                        <div clas="panle body"> <img src="img/7.jpg" class="image-responsive" style="width:100%" alt="Image"> </div>
                        <div class="panel-footer text-light">Precio :  90.000 EUROS </div>
                        <div class="panel-footer text-light float-right"> <a href ="#"> Agregar al carrito </a> </div>
                    </div>
                </div>
                <div class="col-sm-4">

                    <div class="panel panle-primary">

                        <div class="panel-heading text-light"> Reloj Louis Moinet Meteoris </div>
                        <div clas="panle body"> <img src="img/8.jpg" class="image-responsive" style="width:100%" alt="Image"> </div>
                        <div class="panel-footer text-light">Precio : 45.000 USD </div>
                        <div class="panel-footer text-light float-right"> <a href ="#"> Agregar al carrito </a> </div>
                    </div>
                </div>
            </div>
        </div>


        <footer class="container-fluid text-center">
            <div class="container bg-light">
              <p class="text-dark">Online Store Copyright</p> 
           </div> 
       </footer>

    </body>

</html>