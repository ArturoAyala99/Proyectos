<?php

$dbname = "Tienda";
$dbuser = "root"; //es el superusuario
$dbhost = "localhost";
$dbpass = "";

$conexion = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);

?>