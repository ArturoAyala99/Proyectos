<!DOCTYPE html>
<html>
    <head>

        <title>Página Web con Principal</title>

        <meta charset="utf-8">

        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"> <!--para que sea responsivo-->
        <link rel = "stylesheet" type = "text/css" href = "bootstrap-4.5.3-dist/css/bootstrap.min.css">
        <link rel = "stylesheet" type = "text/css" href = "bootstrap-4.5.3-dist/css/bootstrap-grid.min.css">
        <link rel = "stylesheet" type = "text/css" href = "bootstrap-4.5.3-dist/css/bootstrap-reboot.min.css">

        <script type = "text/JavaScript" src = "bootstrap-4.5.3-dist/js/jquery-3.5.1.min.js"> </script>
        <script type = "text/JavaScript" src = "bootstrap-4.5.3-dist/js/bootstrap.min.js"> </script>
        <script type = "text/JavaScript" src = "bootstrap-4.5.3-dist/js/bootstrap.bundle.min.js"> </script>

    </head>


    <body class = "bg-dark">
        <header> 
            <div class="container color bg-light" style="opacity:.8;"> <!--cabezote blanco-->

                <div class = "row">

                    <div class="col-sm">

                      <h5>Bienvenido
                        <?php
                          $nombre;
                          if(isset($_GET['nombre']))
                          {
                            $nombre = $_GET['nombre'];
                          }
                          else
                          {
                            $nombre= "usuario";
                          }
                          echo "".$nombre;
                        
                        ?>
                      
                    </div>

                    <div class="col-sm">

                      <a href = "principal.php" class="nav-link text-dark"> <h1 class="text-center">Tienda online</h1> </a>
                    </div>

                    <div class="col-sm">
    
                      <a href = "login.php"> <img src="img/login.jpg" class = "rounded mx-auto d-block img-fluid float-right" width = "50px"> </a>
                    </div>
                </div>
            </div>
        </header> <br><br>


        <div class="container bg-info rounded" style="padding-bottom: 30px; margin-bottom: 20px;">
            <h1 class="text-center font-italic">Opciones</h1> <br>

            <div class="row">

                <div class="col-6">
                    <div class="container bg-light rounded">

                      <h1 class="text-center font-italic">Catálogo de Productos</h1><br>
                      <a href="catalogo.php" > <img src="img/catalogo.jpg" class = "rounded mx-auto d-block img-fluid center"  width = "300px"> </a>
                    </div> 
                </div>

                <div class="col-6">
                    <div class="container bg-light rounded">

                      <h1 class="text-center font-italic">Carrito de Productos</h1><br>
                      <a href ="carrito.php"> <img src="img/carrito.jpg" class = "rounded mx-auto d-block img-fluid center" width = "300px"> </a>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>